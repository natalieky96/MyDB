package com.example.mydb;

public class UserModel {

    private int id;
    private String name;
    private String email;
    private String password;
    private boolean email_update;

    public UserModel(int id, String name, String email, String password, boolean email_update) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.password = password;
        this.email_update = email_update;
    }

    public int getId(){
        return id;
    }

    public void setId(int id){
        this.id = id;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isEmail_update() {
        return email_update;
    }

    public void setEmail_update(boolean email_update) {
        this.email_update = email_update;
    }

    @Override
    public String toString() {
        return  "id="+ id+
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", password='" + password + '\'' +
                ", email_update=" + email_update +
                '}';
    }
}
