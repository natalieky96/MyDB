package com.example.mydb;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    EditText name, email,password;
    Button btn_add, btn_viewall;
    Switch mail_update;
    ListView user_list;
    ArrayAdapter userArrayAdapter;
    DataBaseHelper dataBaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
         setContentView(R.layout.activity_main);

        name = (EditText) findViewById(R.id.user_name);
        email = (EditText) findViewById(R.id.user_email);
        password = (EditText) findViewById(R.id.user_password);
        mail_update = (Switch) findViewById(R.id.switch1);
        btn_add = (Button) findViewById(R.id.btn_add);
        btn_viewall = (Button) findViewById(R.id.btn_viewall);
        user_list = findViewById(R.id.lst_users);

        showItems();

        btn_add.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                UserModel usermodel;
                try {
                    usermodel = new UserModel(-1, name.getText().toString(), email.getText().toString(), password.getText().toString(), mail_update.isChecked());

                    Toast.makeText(MainActivity.this, "Added", Toast.LENGTH_SHORT).show();
                }
                catch (Exception e){
                    Toast.makeText(MainActivity.this, "Error Creating user", Toast.LENGTH_SHORT).show();
                    usermodel = new UserModel(-1,"error", "error", "error", false);

                }

                DataBaseHelper dataBaseHelper = new DataBaseHelper(MainActivity.this);
                boolean success = dataBaseHelper.addOne(usermodel);
                Toast.makeText(MainActivity.this, "success="+success, Toast.LENGTH_SHORT).show();
                userArrayAdapter = new ArrayAdapter<UserModel>(MainActivity.this, android.R.layout.simple_list_item_1,dataBaseHelper.getEveryone());
                user_list.setAdapter(userArrayAdapter);
            }

        });
        btn_viewall.setOnClickListener(new OnClickListener() {

            public void onClick(View view) {
                showItems();

                //Toast.makeText(MainActivity.this, everyone.toString(), Toast.LENGTH_SHORT).show();
            }
        });

//        user_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long l) {
//                UserModel clickedUser = (UserModel) parent.getItemAtPosition(position);
//                dataBaseHelper.deleteUser(clickedUser);
//                Toast.makeText(MainActivity.this, "Deleted"+clickedUser.toString(), Toast.LENGTH_SHORT).show();
//            }
//        });


    }

    private void showItems() {
        DataBaseHelper dataBaseHelper = new DataBaseHelper(MainActivity.this);
        userArrayAdapter = new ArrayAdapter<UserModel>(MainActivity.this, android.R.layout.simple_list_item_1,dataBaseHelper.getEveryone());
        user_list.setAdapter(userArrayAdapter);
    }
}